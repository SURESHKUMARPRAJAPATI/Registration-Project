﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Registration_Form.Models
{
    public class Login
    {
        public int id { get; set; }
        [Required (ErrorMessage ="Please Enter Your First Name")]
        [StringLength(20)]
        public string Firstname { get; set; }
        [Required(ErrorMessage ="Please Enter Your Last Name")]
        public string Lastname { get; set; }
        [Required(ErrorMessage ="Please Enter Your Date Of Birth")]
        public string DOB { get; set; }
        [Required(ErrorMessage ="Please Enter Your User Name")]
        [DataType(DataType.EmailAddress)]
        public string Username { get; set; }
        [Required (ErrorMessage ="Please Enter Your Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
       

    }
}
