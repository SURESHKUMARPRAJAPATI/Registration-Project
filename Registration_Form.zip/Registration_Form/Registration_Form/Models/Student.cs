﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Registration_Form.Models
{
    public class Student
    {
        [Required]
        public int Id { get; set; }
        [Required(ErrorMessage ="Please Enter Your Name")]
        public String Name { get; set; }
        [Required(ErrorMessage ="Please Enter Your Father's Name")]
        public String Father_Name { get; set; }
        [Required(ErrorMessage ="Please Enter Your Mother's Name")]
        public String Mother_Name { get; set; }
        [Required(ErrorMessage ="Please Enter Your Mobile Number")]
        public String Mobile_No { get; set; }
        [Required(ErrorMessage ="Please Enter Your Adhar Number")]
        public String Adhar_No { get; set; }
        [Required(ErrorMessage ="Please Enter Your Address")]
        public String Address { get; set; }
    }
}
