﻿using Microsoft.AspNetCore.Mvc;
using Registration_Form.Models;
using Registration_Form.Models.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Registration_Form.Controllers
{
    public class StudentController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public StudentController(ApplicationDbContext DbContext)
        {
            dbContext = DbContext;
        }

        public IActionResult Index()
        {
            
            var result = dbContext.students.ToList();

            return View(result);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student model)
        {
            if (ModelState.IsValid)
            {
                //var stu = new Student()
                //{
                //    Name = model.Name,
                //    Father_Name = model.Father_Name,
                //    Mother_Name = model.Mother_Name,
                //    Mobile_No = model.Mobile_No,
                //    Adhar_No = model.Adhar_No,
                //    Address = model.Address
                //};
                //dbContext.students.Add(stu);
                //dbContext.SaveChanges();
                //return RedirectToAction("Index");

                if (dbContext.students.Any(st => st.Adhar_No.Equals(model.Adhar_No)))
                {
                    ViewBag.Error = "Adhar Number already exists!";
                    return View();
                }

                else
                {
                    dbContext.students.Add(model);
                    dbContext.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
                    return View(model);
            
        }
        public IActionResult Edit(int id)
        {
            var stu1 = dbContext.students.SingleOrDefault(s => s.Id == id);
            var result = new Student()
            {
                Name = stu1.Name,
                Father_Name = stu1.Father_Name,
                Mother_Name = stu1.Mother_Name,
                Mobile_No = stu1.Mobile_No,
                Adhar_No = stu1.Adhar_No,
                Address = stu1.Address
            };
            return View(result);
            
        }
        [HttpPost]
        public IActionResult Edit(Student model)
        {
            //var stu1 = new Student()
            //{
            //    Id=model.Id,
            //    Name = model.Name,
            //    Father_Name = model.Father_Name,
            //    Mother_Name = model.Mother_Name,
            //    Mobile_No = model.Mobile_No,
            //    Adhar_No = model.Adhar_No,
            //    Address = model.Address
            //};
            if (ModelState.IsValid)
            {
                if (dbContext.students.Any(st => st.Adhar_No.Equals(model.Adhar_No)))
                {
                    ViewBag.Error = "Adhar Number already exists!";
                    return View();
                }

                else
                {
                    dbContext.students.Add(model);
                    dbContext.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            return View(model);
        }
        public IActionResult Delete(int id)
        {
            var stu = dbContext.students.SingleOrDefault(s => s.Id==id);
            dbContext.students.Remove(stu);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
