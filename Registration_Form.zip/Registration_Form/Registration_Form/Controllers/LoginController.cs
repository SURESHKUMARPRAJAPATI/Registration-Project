﻿using Microsoft.AspNetCore.Mvc;
using Registration_Form.Models;
using Registration_Form.Models.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Registration_Form.Controllers
{
    public class LoginController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public LoginController(ApplicationDbContext dbContext )
        {
            this.dbContext = dbContext;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(Login Id)
        {
            var data = dbContext.logins.Where(Model => Model.Username ==Id.Username && Model.Password ==Id.Password).SingleOrDefault();
            if (data == null)
            {
                ViewBag.Error = "Please Enter Correct Password!";
                return View();
            }
            {
                return RedirectToAction("Index", "Student");
            }
        }
        public IActionResult Registration()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Registration(Login model)
        {

            if (ModelState.IsValid)
            {
                var log = new Login()
                {
                    Firstname = model.Firstname,
                    Lastname = model.Lastname,
                    DOB = model.DOB,
                    Username = model.Username,
                    Password = model.Password
                };

                dbContext.logins.Add(model);
                dbContext.SaveChanges();
                return RedirectToAction("");
            }
            else
            {
                return View(model);
            }
        }
    
    }
}
